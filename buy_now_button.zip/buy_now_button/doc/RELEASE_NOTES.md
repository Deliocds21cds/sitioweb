## Module <buy_now_button>

#### 29.07.2019
#### Version 12.0.1.0.0
##### ADD
Initial Commit for 'buy_now_button'

#### 26.08.2019
#### Version 12.0.1.1.0
##### CHG
View Changed
